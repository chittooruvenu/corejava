package test;

import java.math.BigDecimal;
import java.util.List;

public class Papers {
	private String paperName;
	BigDecimal cost;
	
	public BigDecimal getCost() {
		return cost;
	}

	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}

	
	public String getPaperName() {
		return paperName;
	}

	public void setPaperName(String paperName) {
		this.paperName = paperName;
	} 

}
