package test;
interface Uiframework{
	public void createButton();
}
class A implements Uiframework{
	public void createButton(){
		System.out.println("A class createButton");
	}
}
class B extends A{

	public void createButton(){
		System.out.println("B class createButton");
	}
}
class test{
	
	public B createButton(){
		System.out.println("test class createButton");
		return new B();
		
	}
	

}
public class SquareButton  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Uiframework ui=new B();
		ui.createButton();
		test test=new test();
		test.createButton();
	}

}
