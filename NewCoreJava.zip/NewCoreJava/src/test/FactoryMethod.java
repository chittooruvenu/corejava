package test;

public interface FactoryMethod {
	public void createButton();

}
