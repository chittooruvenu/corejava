package test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class Monthsummary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		getPaperAmountByYear("TOI,Hindu,ET,BM,HT");

	}

	private static Map<String, List<Papers>> getDaysMap() {
		Map<String, List<Papers>> daysMap = new HashMap();

		
		// for monday
				List<Papers> papersMonday = new ArrayList();

				Papers paperToi1 = new Papers();
				paperToi1.setPaperName("TOI");
				paperToi1.setCost(new BigDecimal("3"));

				Papers paperHindu1 = new Papers();
				paperHindu1.setPaperName("Hindu");
				paperHindu1.setCost(new BigDecimal("2.5"));

				
				Papers paperET1 = new Papers();
				paperET1.setPaperName("ET");
				paperET1.setCost(new BigDecimal("2"));
				
				Papers paperBM1 = new Papers();
				paperBM1.setPaperName("BM");
				paperBM1.setCost(new BigDecimal("1.5"));
				
				Papers paperHT1 = new Papers();
				paperHT1.setPaperName("HT");
				paperHT1.setCost(new BigDecimal("2"));
				
				papersMonday.add(paperToi1);
				papersMonday.add(paperHindu1);
				papersMonday.add(paperET1);
				papersMonday.add(paperBM1);
				papersMonday.add(paperBM1);
		// for Tuesday
		List<Papers> papersTuesday = new ArrayList();

		Papers paperToi2 = new Papers();
		paperToi2.setPaperName("TOI");
		paperToi2.setCost(new BigDecimal("3"));

		Papers paperHindu2 = new Papers();
		paperHindu2.setPaperName("Hindu");
		paperHindu2.setCost(new BigDecimal("2.5"));

		
		
		
		
		Papers paperET2 = new Papers();
		paperET2.setPaperName("ET");
		paperET2.setCost(new BigDecimal("2"));
		
		Papers paperBM2 = new Papers();
		paperBM2.setPaperName("BM");
		paperBM2.setCost(new BigDecimal("1.5"));
		
		Papers paperHT2 = new Papers();
		paperHT2.setPaperName("HT");
		paperHT2.setCost(new BigDecimal("2"));
		
		
		papersTuesday.add(paperToi2);
		papersTuesday.add(paperHindu2);
		papersTuesday.add(paperET2);
		papersTuesday.add(paperBM2);
		papersTuesday.add(paperHT2);
		
		
		// for Wednesday
		List<Papers> paperswednesDay = new ArrayList();

		Papers paperToi3 = new Papers();
		paperToi3.setPaperName("TOI");
		paperToi3.setCost(new BigDecimal("3"));

		Papers paperHindu3 = new Papers();
		paperHindu3.setPaperName("Hindu");
		paperHindu3.setCost(new BigDecimal("2.5"));


		Papers paperET3 = new Papers();
		paperET3.setPaperName("ET");
		paperET3.setCost(new BigDecimal("2"));

		Papers paperBM3 = new Papers();
		paperBM3.setPaperName("BM");
		paperBM3.setCost(new BigDecimal("1.5"));

		Papers paperHT3 = new Papers();
		paperHT3.setPaperName("HT");
		paperHT3.setCost(new BigDecimal("2"));

		
		
		paperswednesDay.add(paperToi3);
		paperswednesDay.add(paperHindu3);
		paperswednesDay.add(paperET3);
		paperswednesDay.add(paperBM3);
		paperswednesDay.add(paperHT3);
		
		

		

		// for Thursday
				List<Papers> papersThursday = new ArrayList();

				Papers paperToi4 = new Papers();
				paperToi4.setPaperName("TOI");
				paperToi4.setCost(new BigDecimal("3"));

				Papers paperHindu4 = new Papers();
				paperHindu4.setPaperName("Hindu");
				paperHindu4.setCost(new BigDecimal("2.5"));
				
				
				

				Papers paperET4 = new Papers();
				paperET4.setPaperName("ET");
				paperET4.setCost(new BigDecimal("2"));

				Papers paperBM4 = new Papers();
				paperBM4.setPaperName("BM");
				paperBM4.setCost(new BigDecimal("1.5"));

				Papers paperHT4 = new Papers();
				paperHT4.setPaperName("HT");
				paperHT4.setCost(new BigDecimal("2"));

				papersThursday.add(paperToi4);
				papersThursday.add(paperHindu4);
				papersThursday.add(paperET4);
				papersThursday.add(paperBM4);
				papersThursday.add(paperHT4);

		// for Friday
		List<Papers> papersFriday = new ArrayList();

		Papers paperToi5 = new Papers();
		paperToi5.setPaperName("TOI");
		paperToi5.setCost(new BigDecimal("3"));

		Papers paperHindu5 = new Papers();
		paperHindu5.setPaperName("Hindu");
		paperHindu5.setCost(new BigDecimal("2.5"));
		
		
		
		Papers paperET5 = new Papers();
		paperET5.setPaperName("ET");
		paperET5.setCost(new BigDecimal("2"));

		Papers paperBM5 = new Papers();
		paperBM5.setPaperName("BM");
		paperBM5.setCost(new BigDecimal("1.5"));

		Papers paperHT5 = new Papers();
		paperHT5.setPaperName("HT");
		paperHT5.setCost(new BigDecimal("2"));

		papersFriday.add(paperToi5);
		papersFriday.add(paperHindu5);
		papersFriday.add(paperET5);
		papersFriday.add(paperBM5);
		papersFriday.add(paperHT5);
		
		
		// for Saturday
		List<Papers> papersSaturday = new ArrayList();

		Papers paperToi6 = new Papers();
		paperToi6.setPaperName("TOI");
		paperToi6.setCost(new BigDecimal("5"));

		Papers paperHindu6 = new Papers();
		paperHindu6.setPaperName("Hindu");
		paperHindu6.setCost(new BigDecimal("4"));
		
		

		Papers paperET6 = new Papers();
		paperET6.setPaperName("ET");
		paperET6.setCost(new BigDecimal("2"));

		Papers paperBM6 = new Papers();
		paperBM6.setPaperName("BM");
		paperBM6.setCost(new BigDecimal("1.5"));

		Papers paperHT6 = new Papers();
		paperHT6.setPaperName("HT");
		paperHT6.setCost(new BigDecimal("4"));


		papersSaturday.add(paperToi6);
		papersSaturday.add(paperHindu6);
		papersSaturday.add(paperET6);
		papersSaturday.add(paperBM6);
		papersSaturday.add(paperHT6);		
		
		// for Sunday
		List<Papers> paperSunday = new ArrayList();

		Papers paperToi7 = new Papers();
		paperToi7.setPaperName("TOI");
		paperToi7.setCost(new BigDecimal("6"));

		Papers paperHindu7 = new Papers();
		paperHindu7.setPaperName("Hindu");
		paperHindu7.setCost(new BigDecimal("4"));
		

		Papers paperET7 = new Papers();
		paperET7.setPaperName("ET");
		paperET7.setCost(new BigDecimal("10"));

		Papers paperBM7 = new Papers();
		paperBM7.setPaperName("BM");
		paperBM7.setCost(new BigDecimal("1.5"));

		Papers paperHT7 = new Papers();
		paperHT7.setPaperName("HT");
		paperHT7.setCost(new BigDecimal("4"));

		
		paperSunday.add(paperToi7);
		paperSunday.add(paperHindu7);
		paperSunday.add(paperET7);
		paperSunday.add(paperBM7);
		paperSunday.add(paperHT7);
		
		
		
		daysMap.put("Monday", papersMonday);
		daysMap.put("Tuesday", papersTuesday);
		daysMap.put("Wednesday", paperswednesDay);
		daysMap.put("Thursday", papersThursday);
		daysMap.put("Friday", papersFriday);
		daysMap.put("Saturday", papersSaturday);
		daysMap.put("Sunday", paperSunday);
		
		return daysMap;
	}

	private static void getPaperAmountByYear(String input) {
		String papers[] = input.split(",");
		List<String> papersList = new ArrayList();
		Map<String, List<Papers>> paperMap = getDaysMap();
			Map countbyYear=new HashMap();;
		Map dayscount = null;
		
		for (Calender day : Calender.values()) {
			
			dayscount = GfG.occurrenceDays(day.getDays(), day.getDay());
			
			for (String paper : papers) {
				BigDecimal cost = new BigDecimal(0);		
				Set set2 = paperMap.entrySet();
				Iterator iterator2 = set2.iterator();
				while (iterator2.hasNext()) {
					Map.Entry<String, List<Papers>> me2 = (Map.Entry) iterator2
							.next();
					// System.out.print(me2.getKey() + ": ");
					Integer numberOfDays = (Integer) dayscount
							.get(me2.getKey());

					for (Papers p : me2.getValue()) {

						if (paper.equals(p.getPaperName())) {
							cost.add(p.getCost());
							int no = numberOfDays;
							cost = cost.add(p.getCost().multiply(
									new BigDecimal(no)));
						
						}

					}

				}
				
				if(!countbyYear.containsKey(paper)){
					countbyYear.put(paper, cost);	
				}
				else{
					BigDecimal costForPaper =(BigDecimal)countbyYear.get(paper);
					costForPaper=costForPaper.add(cost);
					countbyYear.put(paper, costForPaper);
					//System.out.println(paper+" final cost=========="+countbyYear.get(paper));
				}
				System.out.println(paper + " Final cost is " + cost+" for month "+day.toString());
				
			}
			
			
			
		}
		Set<Entry<String, BigDecimal>> entries =countbyYear.entrySet();
		for (Entry<String, BigDecimal> entry : entries) {
			System.out.println(entry.getKey() + " Paper Cost For Year==> " + entry.getValue().toString());
		}
	}
}
