package test;

public class Days {
private Papers paper;

public Papers getPaper() {
	return paper;
}

public void setPaper(Papers paper) {
	this.paper = paper;
}
}
