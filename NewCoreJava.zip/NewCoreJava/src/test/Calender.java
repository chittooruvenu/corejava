package test;

public enum Calender {
	JAN(31,"Wednesday"),
	FEB(29,"Saturday"),
	MAR(31,"Sunday"),
	APR(30,"Wednesday"),
	MAY(31,"Friday"),
	JUN(30,"Monday"),
	JULY(31,"Wednesday"),
	AUG(31,"Saturday"),
	SEP(30,"Tuesday"),
	OCT(31,"Thursday"),
	NOV(30,"Sunday"),
	DEC(31,"Tuesday");
	
	public int getDays() {
		return days;
	}

	public void setDays(int days) {
		this.days = days;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	private int days;
	private String day;
	
	Calender(int n,String day){
		this.days=n;
		this.day=day;
	}
	
}
