package test;

public class AmountConstant {
	public static void main(String argc[]) {
		boolean flag = false;
		boolean flag1 = true;
		if (flag1) {
			for (int i = 0; i < 2; i++) {
				System.out.println("true");
			}
		}
		if (!flag) {
			System.out.println("flase");
		}
	}

}
